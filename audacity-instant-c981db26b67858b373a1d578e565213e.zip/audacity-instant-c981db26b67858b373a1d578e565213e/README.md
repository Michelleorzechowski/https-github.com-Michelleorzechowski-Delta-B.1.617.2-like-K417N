# Audacity Instant Zipfile Download

This file has been downloaded from the *Audacity Instant App*, located on the [GISAID](http://www.gisaid.org) website (login required). The *Audacity Instant App* finds closely related COVID-19 sequences to those uploaded and provides valuable metadata about the related sequences, such as their [Clade](https://www.gisaid.org/references/statements-clarifications/clade-and-lineage-nomenclature-aids-in-genomic-epidemiology-of-active-hcov-19-viruses/), Lineage, Location, and the Date they were submitted.

This zipfile contains the following files:

* `placements.csv`: Information about how confident Audacity Instant was in *placing* each uploaded sequence (1 per row, more information below).
* `neighbours.csv`: Related sequences and accompanying metadata (many per uploaded sequence, more information below)
* `EPI-00-{uploaded-sequence-name}.txt`: One text file per uploaded sequence containing a list of the neighbouring GISAID accession identifiers (EPI_ISL_xxxxxx).
* `LICENSE.html`: A copy of the GISAID license.
* `README.md`: This README file (in Markdown format)

## What is in `placements.csv`?

Audacity Instant tries to place each uploaded sequence in the most likely position 
on a Phylogenetic tree built with existing sequences. The columns in the placements table indicate how confidently Audacity Instant was able to place the uploaded sequence. Audacity Instant identifies a candidate sequence with high similarity to the uploaded sequence (i.e., closest neighbour in Phylogenetic tree). Data columns on this neighbour are also included in the file for comparison (prefixed with `neighbour`).  Note that there may be additional sequences that are equally similar (see the `neighbours.csv`).

| Field                    | Description                                                        |
| --                       | --                                                                 |
| uploaded                 | Name of uploaded sequence                                          |
| placements               | Number of different placements in tree                             |
| message                  | The message given by the placement tool `usher`                    |
| mutation_path            | The path of mutations from the reference sequence                  |
| neighbour                | Name of candidate close neighbour                                  |
| neighbour_clade          | Clade designation                                                  |
| neighbour_lineage        | Pango/Scorpio lineage designation                                  |
| neighbour_distance       | Number of mutations between neighbour and placed sequences on tree |
| neighbour_prot_mutations | Protein mutations in neighbour                                     | 


## What is in `neighbours.csv`?

For brevity, we refer to the uploaded sequence as *uploaded* and the closest neighbour sequence as *neighbour*. The ‘neighbours.csv’ contains information on additional similar sequences, i.e. neighbours, to the upload.  Each row contains one *uploaded* sequence and a *neighbour* sequence. The number of mutations referred to is derived from the Phylogenetic tree used to do the placement.

| Field        | Description                                                                                      |
| --           | --                                                                                               |
| uploaded     | Name of *upload* (from fasta file or text)                                                       |
| name         | Name of *neighbour* sequence                                                                     |
| id           | GISAID accession id of *neighbour* sequence (unique for every sequence)                          |
| clade        | Clade designation of *neighbour*                                                                 |
| lineage      | Pango/Scorpio lineage designation of *neighbour*                                                 |
| mrca         | Number of mutations between *uploaded* and the first ancestor of both *neighbour* and *uploaded* |
| distance     | Number of mutations between *uploaded* sequence and the neighbour                                |
| location     | Where the *neighbour* was collected                                                              |
| collect_date | Date *neighbour* was collected (YYYY-MM-DD format)                                               |
| submit_date  | Date *neighbour* was submitted to GISAID (YYYY-MM-DD format)                                     |
| authors      | Authors                                                                                          |
| orig_lab     | Originating lab                                                                                  |
| submit_lab   | Submitting lab                                                                                   |

## How does Audacity Instant work?

Here is a brief description of the steps that produce these results. 

1. The uploaded sequences is aligned to the reference sequences using mafft;
2. The sequence is masked, removing a number of low quality sites;
3. The masked sequence is placed on the GISAID Audacity tree using maximum parsimony;
4. The resulting tree is traversed to find neighbouring sequences;
5. These sequences are annotated with metadata from GISAID.


